#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include <process.h>/*exit()*/

#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
