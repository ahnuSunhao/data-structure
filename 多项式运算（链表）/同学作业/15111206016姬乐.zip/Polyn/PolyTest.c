#include "Common.h"

int main()
{
	int i;
	polyn P1,P2;
	PRINT();
	do
	{
		scanf("%d",&i);
		switch(i)
		{
		case 1:CreatPolyn(&P1);break;
		case 2:CreatPolyn(&P2);break;
		case 3:PrintPolyn(&P1);break;
		case 4:PrintPolyn(&P2);break;
		case 5:AddPolyn(P1,P2);break;
		case 6:SubPolyn(P1,P2);break;
		case 7:MulPolyn(P1,P2);break;
		case 8:DestoryPolyn(&P1);break;
		case 9:DestoryPolyn(&P2);break;
		}
	}while(i!=0);
	return 0;
}