#include "Common.h"

void PRINT()
{
	printf("************************************\n");
	printf("*1������һ��һԪ����ʽ**************\n");
	printf("*2�����ڶ���һԪ����ʽ**************\n");
	printf("*3�����һ��һԪ����ʽ**************\n");
	printf("*4����ڶ���һԪ����ʽ**************\n");
	printf("*5������ǵĺ�**********************\n");
	printf("*6������ǵĲ�**********************\n");
	printf("*7������ǵĻ�**********************\n");
	printf("*8���ٵ�һ��һԪ����ʽ**************\n");
	printf("*9���ٵڶ���һԪ����ʽ**************\n");
	printf("***************��0�˳�**************\n");
}

void CreatPolyn(polyn *P)
{
	//������ʾһԪ����ʽ������P 
	int n,i;
	polyn *s;
	P->next=NULL;
	printf("���������ʽ��������\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
         s=(Link)malloc(sizeof(polyn));
		 scanf("%f %d",&(s->coef),&(s->expn));
		 s->next=P->next;
		 P->next=s;//�ڵ���뵽��ͷ������
	}
	MergePolyn(P);
	DeleZeroPolyn(P);
    SortPolyn(P);
}//CreatPolyn

void MergePolyn(polyn *P)
{
	//��һԪ����ʽ�������ͬ�Ľ��кϲ�����ɾȥ�ϲ���Ľ��
	polyn *s,*q,*ptr,*ptr1,*p,*ptr2;
	s=P->next;
	for(s;s!=NULL;s=s->next)
	{
		for(q=s->next,ptr=s;q!=NULL;)
		{
			if(s->expn==q->expn)
			{
				s->coef+=q->coef;
				ptr->next=q->next;
				ptr1=q;
				q=q->next;
				free(ptr1);
			}
			else
			{
				ptr=ptr->next;
				q=q->next;
			}
		}
	}
}//MergePolyn

void DeleZeroPolyn(polyn *P)
{
	polyn *s,*ptr,*p,*q;
	s=P->next;
	while(s)
	{
		if(s->coef==0)
		{
			p=P;
			while(p->next!=s)
			{
				p=p->next;
			}
			ptr=p->next;
		    p->next=ptr->next;
			s=p->next;
		    free(ptr);
		}
		else
		{
		    s=s->next;
		}
	}
}

void SortPolyn(polyn *P)
{
	//�Ա��и��ڵ㰴�մ������Ĵ����������
	polyn *p,*q,*s;
	float f;
	int i;
	p=P->next;
	q=p->next;
	s=P;
	while(s)
	{
		p=P->next;
		q=p->next;
		for(p,q;q;p=p->next,q=q->next)
		{
			if(p->expn>q->expn)
			{
				f=p->coef;
				i=p->expn;
				p->coef=q->coef;
				p->expn=q->expn;
				q->coef=f;
				q->expn=i;
			}
		}
		s=s->next;
	}
}//SortPolyn

void PrintPolyn(polyn *P)
{
    //��ӡ��һԪ����ʽ
	polyn *s,*q;
	int count=0;
	s=P->next;
	    while(s->next)
		{
		    if(s->expn==0)
			{
			     printf("%.1f+",s->coef);
			}
		    else if(s->expn==1)
			{

			    if(s->coef==1)
				{
				    printf("X+");
				}
			    else
				{
			        printf("%.1fX+",s->coef);
				}
			}
		    else
			{
	            if(s->coef==1)
				{
				    printf("X^%d+",s->expn);
				}
			    else
				{
			        printf("%.1fX^%d+",s->coef,s->expn);
				}
			}
			s=s->next;
		}
	    if(s->expn==0)
	    {
		    printf("+%.1f",s->coef);
	    }
	    else if(s->expn==1)
	    {

		    if(s->coef==1)
		    {
			    printf("+X");
		    }
		    else
		    {
			    printf("+%.1fX",s->coef);
		    }
	    }
	    else
	    {
	        if(s->coef==1)
		    {
			    printf("+X^%d",s->expn);
		    }
		    else
		    {
			    printf("+%.1fX^%d",s->coef,s->expn);
		    }
	   }
    
}//PrintPolyn

void AddPolyn(polyn P1,polyn P2)
{
	//������һԪ����ʽ��Ӳ����
	polyn *p,*q,*s;
	polyn *P0;
	p=P1.next;
	q=P2.next;
	P0=(Link)malloc(sizeof(polyn)); 
	P0->next=NULL;
	while(p&&q)
	{
		if(p->expn<q->expn)
		{
			s=(Link)malloc(sizeof(polyn));
			s->coef=p->coef;
			s->expn=p->expn;
			p=p->next;
			s->next=P0->next;
			P0->next=s;
		}
		else if(p->expn>q->expn)
		{
			s=(Link)malloc(sizeof(polyn));
			s->coef=q->coef;
			s->expn=q->expn;
			q=q->next;
			s->next=P0->next;
			P0->next=s;
		}
		else
		{
			if(p->coef+q->coef!=0)
			{
				s=(Link)malloc(sizeof(polyn));
				s->coef=q->coef+p->coef;
				s->expn=p->expn;
				s->next=P0->next;
				P0->next=s;
			}
			p=p->next;
			q=q->next;
		}
	}
	while(p)
	{
		s=(Link)malloc(sizeof(polyn));
		s->coef=p->coef;
		s->expn=p->expn;
		s->next=P0->next;
		P0->next=s;
		p=p->next;
	}
	while(q)
	{
		s=(Link)malloc(sizeof(polyn));
		s->coef=q->coef;
		s->expn=q->expn;
		s->next=P0->next;
		P0->next=s;
		q=q->next;
	}
	MergePolyn(P0);
	DeleZeroPolyn(P0);
	SortPolyn(P0);
	PrintPolyn(P0);
}//AddPolyn

void SubPolyn(polyn P1,polyn P2)
{
	//������һԪ����ʽ������������
	polyn *p,*q,*s;
	polyn *P0;
	p=P1.next;
	q=P2.next;
	P0=(Link)malloc(sizeof(polyn));
	P0->next=NULL;
	while(p&&q)
	{
		if(p->expn<q->expn)
		{
			s=(Link)malloc(sizeof(polyn));
			s->coef=p->coef;
			s->expn=p->expn;
			p=p->next;
			s->next=P0->next;
			P0->next=s;
		}
		else if(p->expn>q->expn)
		{
			s=(Link)malloc(sizeof(polyn));
			s->coef=q->coef;
			s->expn=q->expn;
			q=q->next;
			s->next=P0->next;
			P0->next=s;
		}
		else
		{
			if(p->coef-q->coef!=0)
			{
				s=(Link)malloc(sizeof(polyn));
				s->coef=p->coef-q->coef;
				s->expn=p->expn;
				s->next=P0->next;
				P0->next=s;
			}
			p=p->next;
			q=q->next;
		}
	}
	while(p)
	{
		s=(Link)malloc(sizeof(polyn));
		s->coef=p->coef;
		s->expn=p->expn;
		s->next=P0->next;
		P0->next=s;
		p=p->next;
	}
	while(q)
	{
		s=(Link)malloc(sizeof(polyn));
		s->coef=q->coef;
		s->expn=q->expn;
		s->next=P0->next;
		P0->next=s;
		q=q->next;
	}
	MergePolyn(P0);
	DeleZeroPolyn(P0);
	SortPolyn(P0);
	PrintPolyn(P0);
}//SubPolyn

void MulPolyn(polyn P1,polyn P2)
{
	//������һԪ����ʽ�������
	polyn *p,*q,*s;
	polyn *P0;
    p=P1.next;
	q=P2.next;
	P0=(Link)malloc(sizeof(polyn));
	P0->next=NULL;
	while(p)
	{
        while(q)
		{
			s=(Link)malloc(sizeof(polyn));
			s->coef=p->coef*q->coef;
			s->expn=p->expn+q->expn;
		s->next=P0->next;
		P0->next=s;q=q->next;
		}
		q=P2.next;
		p=p->next;
	}
	MergePolyn(P0);
	DeleZeroPolyn(P0);
	SortPolyn(P0);
	PrintPolyn(P0);
}

void DestoryPolyn(polyn *P)
{
	//��������
    polyn *s,*q;
	s=P->next;
	while(s)
	{
		q=s;
		s=s->next;
		free(q);
	}
	P=NULL;
}//DestoryPolyn 