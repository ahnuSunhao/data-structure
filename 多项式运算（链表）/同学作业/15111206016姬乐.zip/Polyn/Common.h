#include <stdio.h>
#include <stdlib.h>

typedef struct LNode
{
	float coef;
	int expn;
	struct LNode *next;
}polyn,*Link;

void PRINT();

void CreatPolyn(polyn *P);

void MergePolyn(polyn *P);

void SortPolyn(polyn *P);

void DeleZeroPolyn(polyn *P);

void PrintPolyn(polyn *P);

void AddPolyn(polyn P1,polyn P2);

void SubPolyn(polyn P1,polyn P2);

void MulPolyn(polyn P1,polyn P2);

void DestoryPolyn(polyn *P);