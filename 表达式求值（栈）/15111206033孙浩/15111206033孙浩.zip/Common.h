#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
#include <process.h>

#define ERROR 0
#define OK 1
#define STACK_INIT_SIZE 100
#define STACKINCREMENT 10

typedef int Status;